# Claude Coworkワークショップ 事前配布資料

## このフォルダに入っているもの

- `workshop_guide.html` — ワークショップ進行ガイド（ブラウザで開いてください）
- `worksheet.docx` — ワークシート（印刷 or 画面で記入）
- `kadai2_survey_responses/` — 課題②の素材

※ 課題①はCoworkにWeb検索で情報を集めてもらう形式のため、素材フォルダはありません。

## ワークショップ当日までに準備すること

1. **Claude Desktopをインストール**
   - まだの方: claude.com/download から
   - すでにある方: 最新版にアップデート
2. **このフォルダを好きな場所に配置**
   - Desktop、Documents配下など、Coworkから指定しやすい場所に
3. **workshop_guide.html を一度開いて流し読み**
   - 15分もあれば読めます
4. **Claude Desktopで Cowork タブが見えることを確認**
   - Pro/Max/Team/Enterpriseプランが必要です

## 当日の流れ

workshop_guide.html を開いて、上から順に進めていきます。
課題①（Web検索で情報収集）→ 課題②（ファイル横断処理）→ 自分の業務への適用、の順です。

## 注意

課題②のアンケートデータは研修用の架空データです。
